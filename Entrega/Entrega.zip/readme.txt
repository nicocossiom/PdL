jspdl.exe -> ejecutable del programa

diagramadeclases.jpg -> imagen que contiene las clases usadas en el código fuente con sus métodos, para tener una vista general
jspdl.py -> código fuente

memoria.pdf -> memoria del trabajo en formato pdf
memoria.html -> memoria del trabajo en formato html
La diferencia entre ambos aparte del formato es que el pdf no tiene las imágenes incluidas debido a que eran demasiado grandes, por lo que hemos optado en poner
un enlace al repositorio de GitHub donde se ha desarrollado el código y donde están el resto de archivos. 

gramatica.txt -> fichero que contiene la gramática usada por el vast

/images -> carpeta con las dos imágenes usadas en memoria.html